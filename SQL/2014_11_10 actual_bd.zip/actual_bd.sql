-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         5.5.24-log - MySQL Community Server (GPL)
-- SO del servidor:              Win32
-- HeidiSQL Versión:             8.3.0.4694
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Volcando estructura de base de datos para socger
DROP DATABASE IF EXISTS `socger`;
CREATE DATABASE IF NOT EXISTS `socger` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_spanish_ci */;
USE `socger`;


-- Volcando estructura para tabla socger.medio
DROP TABLE IF EXISTS `medio`;
CREATE TABLE IF NOT EXISTS `medio` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  `Insert_WHEN` datetime NOT NULL,
  `Insert_Id_User` bigint(20) NOT NULL,
  `Del_WHEN` datetime DEFAULT NULL,
  `Del_Id_User` bigint(20) DEFAULT NULL,
  `Del_WHY` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `Change_WHEN` datetime DEFAULT NULL,
  `Change_Id_User` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla socger.medio: ~1 rows (aproximadamente)
DELETE FROM `medio`;
/*!40000 ALTER TABLE `medio` DISABLE KEYS */;
INSERT INTO `medio` (`id`, `descripcion`, `Insert_WHEN`, `Insert_Id_User`, `Del_WHEN`, `Del_Id_User`, `Del_WHY`, `Change_WHEN`, `Change_Id_User`) VALUES
	(1, 'DVD', '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `medio` ENABLE KEYS */;


-- Volcando estructura para tabla socger.menus
DROP TABLE IF EXISTS `menus`;
CREATE TABLE IF NOT EXISTS `menus` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Descripcion` varchar(150) NOT NULL DEFAULT '0',
  `Id_Menus` bigint(20) DEFAULT '0',
  `Insert_WHEN` datetime NOT NULL,
  `Insert_Id_User` bigint(20) NOT NULL,
  `Del_WHEN` datetime DEFAULT NULL,
  `Del_Id_User` bigint(20) DEFAULT NULL,
  `Del_WHY` varchar(255) DEFAULT NULL,
  `Change_WHEN` datetime DEFAULT NULL,
  `Change_Id_User` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Index_Descripcion` (`Descripcion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Antes una pequeña aclaración, esta tabla no sólo servirá para tener un código Id por cada módulo (para luego hacer búsquedas por permisos de usuario), sino que también nos servirá para crear el menú de nuestra aplicación. Por lo que un submenu puede derivar de un menu anterior, o incluso de un submenu que deriva de otro submenu que este otro deriva de un menu.\r\n\r\nY por supuesto nos servirá para crear menús adaptables, es decir, un menú que un usuario sólo tenga permisos parciales, el resto de las opciones ó se las dejamos invisibles ó se las dejamos inusuables (propiedad enabled := False)\r\n\r\nPero claro un submenu, necesitará saber de cual otro menú o submenu deriva, de ahí el campo id_Menus\r\n\r\nId ... Autoincremental\r\nDescripcion ... nvarchar (150) ... NOT NULL,\r\nid_Menus ... Integer ... NULL ... para ligar con la tabla de MÓDULOS/MENUS de la APP';

-- Volcando datos para la tabla socger.menus: ~0 rows (aproximadamente)
DELETE FROM `menus`;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;


-- Volcando estructura para tabla socger.peliculas
DROP TABLE IF EXISTS `peliculas`;
CREATE TABLE IF NOT EXISTS `peliculas` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(150) COLLATE utf8_spanish_ci NOT NULL,
  `id_medio` int(10) NOT NULL,
  `Numero` int(10) NOT NULL,
  `Insert_WHEN` datetime NOT NULL,
  `Insert_Id_User` bigint(20) NOT NULL,
  `Del_WHEN` datetime DEFAULT NULL,
  `Del_Id_User` bigint(20) DEFAULT NULL,
  `Del_WHY` varchar(255) COLLATE utf8_spanish_ci DEFAULT NULL,
  `Change_WHEN` datetime DEFAULT NULL,
  `Change_Id_User` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_peliculas_medio` (`id_medio`),
  CONSTRAINT `FK_peliculas_medio` FOREIGN KEY (`id_medio`) REFERENCES `medio` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=210 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- Volcando datos para la tabla socger.peliculas: ~209 rows (aproximadamente)
DELETE FROM `peliculas`;
/*!40000 ALTER TABLE `peliculas` DISABLE KEYS */;
INSERT INTO `peliculas` (`id`, `titulo`, `id_medio`, `Numero`, `Insert_WHEN`, `Insert_Id_User`, `Del_WHEN`, `Del_Id_User`, `Del_WHY`, `Change_WHEN`, `Change_Id_User`) VALUES
	(1, 'ORIGEN', 1, 41, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(2, 'OUTLANDER', 1, 41, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(3, 'SEÑALES DEL FUTURO', 1, 41, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(4, 'SUPERMAN - EL HOMBRE DE ACERO', 1, 40, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(5, 'THE AMAZING SPIDERMAN', 1, 40, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(6, 'LA LEYENDA DEL SAMURAI 47 RONIN', 1, 39, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(7, 'IRON MAN 3', 1, 39, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(8, 'JHON CARTER ', 1, 38, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(9, 'L.A. CONFIDENTIAL', 1, 38, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(10, 'TRANSFORMERS 2', 1, 37, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(11, 'TRANSFORMERS 3', 1, 37, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(12, 'LOS RIOS DE COLOR PURPURA', 1, 36, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(13, 'LOS RIOS DE COLOR PURPURA 2', 1, 36, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(14, 'STAR TREK EN LA OSCURIDAD', 1, 36, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(15, 'ULTIMATUM A LA TIERRA', 1, 35, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(16, 'PRINCE OF PERSIA - LAS ARENAS DEL TIEMPO', 1, 35, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(17, 'SOY EL NUMERO CUATRO', 1, 35, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(18, 'STAR WARS - THE CLONE WARS', 1, 35, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(19, 'LOS VENGADORES', 1, 34, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(20, 'VAN HELLSING', 1, 34, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(21, 'ALIEN IV', 1, 34, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(22, 'THE FINAL FANTASY - LA FUERZA INTERIOR', 1, 33, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(23, 'EL HOMBRE DE ACERO', 1, 33, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(24, 'TERMINATOR - SALVATION', 1, 33, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(25, 'HELL BOY - VERSION EXTENDIDA', 1, 32, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(26, 'HELL BOY 2 - EL EJERCITO DORADO', 1, 32, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(27, 'LARA CROFT 2 - LA CUNA DE LA VIDA', 1, 32, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(28, 'LARA CROFT', 1, 32, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(29, 'ALIEN AL REGRESO', 1, 32, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(30, 'LA ULTIMA LEGION', 1, 31, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(31, 'HULK', 1, 31, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(32, 'EL INCREIBLE HULK', 1, 31, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(33, 'EL HOBBIT - UN VIAJE INESPERADO (VERSION EXTENDIDA)', 1, 30, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(34, 'EL ILUSIONISTA', 1, 30, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(35, 'ANGELES Y DEMONIOS - VERSION EXTENDIDA', 1, 29, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(36, 'EL CODIGO DA VINCI - VERSION EXTENDIDA', 1, 29, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(37, 'WING COMANDER', 1, 29, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(38, 'RIDICK 1', 1, 28, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(39, 'RIDICK 2', 1, 28, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(40, 'RIDICK 3', 1, 28, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(41, 'EL JUEGO DE ENDER', 1, 27, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(42, 'EL SECRETO DE THOMAS CROWN', 1, 27, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(43, 'LA GUERRA DE LOS MUNDOS', 1, 27, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(44, 'MATRIX', 1, 26, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(45, 'MATRIX RELOADED', 1, 26, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(46, 'MATRIX REVOLUTIONS', 1, 26, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(47, 'STAR TREK XI', 1, 25, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(48, 'STAR TREK V - LA ULTIMA FRONTERA', 1, 25, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(49, 'STAR TREK VII, PROXIMA GENERACION', 1, 25, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(50, 'STAR TREK VI, AQUEL PAIS DESCONOCIDO', 1, 25, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(51, 'EL HOBBIT - UN VIAJE INSPERADO', 1, 24, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(52, 'EL SEÑOR DE LOS ANILLOS', 1, 24, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(53, 'BATMAN BEGINS', 1, 23, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(54, 'BATTLESHIP', 1, 23, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(55, 'BEOWULF', 1, 23, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(56, 'BLADE RUNNER', 1, 23, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(57, 'CATWOMAN', 1, 23, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(58, 'DARE DEVIL - DAN DEFENSOR', 1, 23, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(59, 'DRAGON BALL EVOLUTION', 1, 22, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(60, 'CAPITAN AMERICA', 1, 22, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(61, 'CONTACT', 1, 22, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(62, 'CONAN EL BARBARO', 1, 22, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(63, 'DEMOLITION MAN', 1, 22, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(64, 'DESAFIO TOTAL', 1, 22, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(65, 'ERASER', 1, 22, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(66, 'DEJA VU', 1, 22, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(67, 'MENTIRAS ARRIESGADAS', 1, 21, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(68, 'GI JOE', 1, 21, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(69, '2010 ODISEA 2', 1, 21, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(70, 'ATLANTIS', 1, 21, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(71, 'EL PLANETA DEL TESORO', 1, 21, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(72, 'EL QUINTO ELEMENTO', 1, 21, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(73, 'EL UNICO', 1, 21, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(74, 'PRINCE OF PERSIA - LAS ARENAS DEL TIEMPO', 1, 20, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(75, 'IRA DE TITANES', 1, 20, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(76, 'FURIA DE TITANES 2', 1, 20, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(77, 'LINTERNA VERDE', 1, 20, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(78, 'HANCKOK', 1, 19, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(79, 'IRON MAN 1', 1, 19, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(80, 'IRON MAN 2', 1, 19, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(81, 'EL REINO DE LOS CIELOS', 1, 18, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(82, 'ICE AGE 1', 1, 18, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(83, 'ICE AGE 2', 1, 18, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(84, 'LOS JUEGOS DEL HAMBRE', 1, 18, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(85, 'EL FANTASMA DE LA OPERA', 1, 17, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(86, 'SPIDERMAN 1', 1, 17, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(87, 'SPIDERMAN 2', 1, 17, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(88, 'SPIDERMAN 3', 1, 17, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(89, 'LOS CHICOS DEL CORO', 1, 16, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(90, 'MR AND MRS SMITH', 1, 16, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(91, 'JHON CARTER', 1, 16, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(92, 'SONRISAS Y LAGRIMAS', 1, 16, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(93, 'NIVEL 13', 1, 16, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(94, 'LA MOMIA', 1, 15, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(95, 'EL REGRESO DE LA MOMIA', 1, 15, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(96, 'MEN IN BLACK', 1, 15, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(97, 'JUEZ DRED', 1, 15, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(98, 'SHERLOCK HOLMES', 1, 14, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(99, 'SHERLOCK HOLMES, JUEGO DE SOMBRAS', 1, 14, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(100, 'AIRBENDER, EL ULTIMO GUERRERO', 1, 13, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(101, 'DEJA VU', 1, 13, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(102, 'GLADIATOR', 1, 13, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(103, 'LAS AVENTURAS DE TINTIN', 1, 13, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(104, 'LOS 4 FANTASTICOS', 1, 13, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(105, 'LOS 4 FANTASTICOS Y SILVER SURFER', 1, 13, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(106, 'LOS VENGADORES', 1, 12, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(107, 'EXISTEN Z', 1, 12, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(108, 'INDEPENDENCE DAY', 1, 12, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(109, 'INDIANA JONES, EN BUSCA DEL ARCA PERDIDA', 1, 12, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(110, 'INDIANA JONES, EL REINO DE LA CALAVERA', 1, 12, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(111, 'INDIANA JONES, EL TEMPLO MALDITO', 1, 12, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(112, 'INDIANA JONES, LA ULTIMA CRUZADA', 1, 12, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(113, 'HEROES', 1, 11, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(114, 'STARDUST', 1, 11, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(115, 'YO ROBOT', 1, 11, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(116, 'THOR', 1, 10, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(117, 'TITAN AE', 1, 10, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(118, 'TRANSFORMER 3', 1, 10, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(119, 'AGORA', 1, 9, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(120, 'EL PLANETA DE LOS SIMIOS - 2001', 1, 9, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(121, 'STARGATE', 1, 9, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(122, 'THE DARK CRYSTAL', 1, 9, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(123, 'MINORITY REPORT', 1, 8, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(124, 'OPERACION SWORD FISH', 1, 8, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(125, 'REGRESO AL FUTURO II', 1, 8, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(126, 'EL APRENDIZ DE BRUJO', 1, 8, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(127, 'LA GUERRA DE LOS MUNDOS', 1, 8, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(128, 'SOY EL NUMERO CUATRO', 1, 7, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(129, 'LA JUNGLA DE CRISTAL IV', 1, 7, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(130, 'STAR WARS II, EL ATAQUE DE LOS DRONES', 1, 7, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(131, 'STAR WARS I, LA AMENAZA FANTASMA', 1, 6, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(132, 'STAR WARS III, LA VENGANZA DE LOS SITH', 1, 6, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(133, 'STAR WARS IV, LA GUERRA DE LAS GALAXIAS', 1, 6, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(134, 'STAR WARS V, EL IMPERIO CONTRATACA', 1, 6, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(135, 'STAR WARS VI, EL RETORNO DEL JEDI', 1, 6, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(136, 'THE AMAZING SPIDERMAN', 1, 5, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(137, 'OTRA VEZ TU', 1, 5, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(138, 'ROBIN HOOD, PRINCIPE DE LOS LADRONES', 1, 5, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(139, 'AVATAR', 1, 4, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(140, 'PROMETEUS', 1, 4, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(141, 'MISION IMPOSIBLE, PROTOCOLO FANTASMA', 1, 4, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(142, 'TITANIC', 1, 3, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(143, 'X-MEN, ORIGENES LOBEZNO', 1, 3, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(144, 'X-MEN, 1ª GENERACION', 1, 3, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(145, 'SUPERMAN RETURNS', 1, 2, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(146, 'TRON LEGACY', 1, 2, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(147, 'VIAJE AL CENTRO DE LA TIERRA 2', 1, 2, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(148, 'TRON', 1, 2, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(149, 'TERMINATOR 1', 1, 1, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(150, 'TERMINATOR 2', 1, 1, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(151, 'TERMINATOR 3', 1, 1, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(152, 'TERMINATION SALVATION', 1, 1, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(153, 'OBLIVION', 1, 43, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(154, 'LA COMUNIDAD DEL ANILLO - 002 (V.EXTENDIDA)', 1, 43, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(155, 'LA COMUNIDAD DEL ANILLO - 001 (V.EXTENDIDA)', 1, 42, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(156, 'PACIFIC RIM', 1, 42, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(157, 'LA COMUNIDAD DEL ANILLO - 003 (V.EXTENDIDA)', 1, 44, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(158, 'JUMANJI', 1, 44, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(159, 'EL LABERINTO DEL FAUNO', 1, 45, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(160, 'MEMORIAS DE UNA GEISHA', 1, 45, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(161, 'NACER PARA MORIR', 1, 45, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(162, 'LA COMUNIDAD DEL ANILLO - 004 (V.EXTENDIDA) EL HOBBIT', 1, 46, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(163, 'LA COMUNIDAD DEL ANILLO - 005 - EL HOBBIT, LA DESOLACION DE SMAUG', 1, 46, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(164, 'LA LEYENDA DE TERRAMAR', 1, 47, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(165, 'EL VUELO DEL NAVEGANTE', 1, 47, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(166, 'PERCY JACKSON Y EL MAR DE MONSTRUOS', 1, 47, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(167, 'PERCY JACKSON Y EL LADRON DEL RAYO', 1, 47, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(168, 'WILLOW', 1, 47, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(169, 'JOSE EL REY DE LOS SUEÑOS', 1, 48, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(170, 'PELIGRO INMINENTE', 1, 48, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(171, 'SPACE COWBOYS', 1, 48, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(172, 'SPACE JAM', 1, 48, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(173, 'CODIGO FUENTE', 1, 49, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(174, 'EL SEÑOR DE LAS BESTIAS', 1, 49, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(175, 'EL ULTIMO MOHICANO', 1, 49, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(176, 'EL SONIDO DEL TRUENO', 1, 50, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(177, 'LA BRUJULA DORADA', 1, 50, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(178, 'LOS INMORTALES', 1, 50, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(179, 'LOS INMORTALES II', 1, 50, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(180, 'SUPER 8', 1, 50, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(181, 'LA BUSQUEDA', 1, 51, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(182, 'LA BUSQUEDA, EL DIARIO SECRETO', 1, 51, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(183, 'LA MOMIA 3, LA TUMBA DEL EMPERADOR DRAGON', 1, 51, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(184, 'MEN IN BLACK III', 1, 51, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(185, 'LOS INMORTALES III', 1, 52, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(186, 'WATCHMEN', 1, 52, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(187, 'TRANSFORMER 1', 1, 52, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(188, 'LA MANSION ENCANTADA', 1, 53, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(189, 'PERDIDOS EN EL ESPACIO', 1, 53, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(190, 'THE ROCKETEER', 1, 53, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(191, 'JUMPER', 1, 53, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(192, 'HORIZONTE FINAL', 1, 53, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(193, 'DUNE', 1, 53, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(194, 'X-MEN 2', 1, 54, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(195, 'X-MEN 3', 1, 54, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(196, 'THOR 2, EL MUNDO OSCURO', 1, 55, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(197, 'X-MEN 1', 1, 55, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(198, 'X.MEN, ORIGENES LOBEZNO', 1, 55, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(199, 'X-MEN, LOBEZNO INMORTAL (V.EXT)', 1, 56, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(200, 'JUMANJI', 1, 56, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(201, 'ICE AGE 4', 1, 56, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(202, 'ULTRAVIOLETA', 1, 57, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(203, 'WILD WILD WEST', 1, 57, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(204, 'STAR TREK I', 1, 57, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(205, 'TITANIC', 1, 57, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(206, 'FREQUENCY', 1, 57, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(207, 'LA EXTRAÑA PAREJA', 1, 58, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(208, 'BRAVEHEART', 1, 58, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL),
	(209, 'X-MEN, LA PRIMERA GENERACION', 1, 58, '0000-00-00 00:00:00', 0, NULL, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `peliculas` ENABLE KEYS */;


-- Volcando estructura para tabla socger.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Descripcion_Nick` varchar(150) NOT NULL,
  `Id_Empleados` bigint(20) DEFAULT NULL,
  `Permiso_Total_SN` char(1) NOT NULL DEFAULT 'N',
  `Insert_WHEN` datetime NOT NULL,
  `Insert_Id_User` bigint(20) NOT NULL,
  `Del_WHEN` datetime DEFAULT NULL,
  `Del_Id_User` bigint(20) DEFAULT NULL,
  `Del_WHY` varchar(255) DEFAULT NULL,
  `Change_WHEN` datetime DEFAULT NULL,
  `Change_Id_User` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `Index_DescripcionNick` (`Descripcion_Nick`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Id_Empleados ... para ligar con la tabla de personal / empleados (por si el usuario es un empleado de la firma). No es obligatorio este campo\r\nPermiso_Total_SN ...  (S/N) Es el equivalente a un campo boolean por si la BD no admitiera este tipo de campos y el campo equivale a un SUPERUSUARIO';

-- Volcando datos para la tabla socger.users: ~0 rows (aproximadamente)
DELETE FROM `users`;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;


-- Volcando estructura para tabla socger.users_menus
DROP TABLE IF EXISTS `users_menus`;
CREATE TABLE IF NOT EXISTS `users_menus` (
  `Id_Users` bigint(20) NOT NULL,
  `Id_Menus` bigint(20) NOT NULL,
  `Forcing_Why_Delete` char(1) NOT NULL DEFAULT 'S',
  `Insert_WHEN` datetime NOT NULL,
  `Insert_Id_User` bigint(20) NOT NULL,
  `Del_WHEN` datetime DEFAULT NULL,
  `Del_Id_User` bigint(20) DEFAULT NULL,
  `Del_WHY` varchar(255) DEFAULT NULL,
  `Change_WHEN` datetime DEFAULT NULL,
  `Change_Id_User` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`Id_Users`,`Id_Menus`),
  KEY `FK_users_menus_menus` (`Id_Menus`),
  CONSTRAINT `FK_users_menus_menus` FOREIGN KEY (`Id_Menus`) REFERENCES `menus` (`Id`),
  CONSTRAINT `FK_users_menus_users` FOREIGN KEY (`Id_Users`) REFERENCES `users` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Esta tabla registra con que módulos podrá trabajar cada usuario. Pero sólo es para eso para registrar los módulos por usuario. No sus privilegios de uso (ALTAS, BAJAS, CAMBIOS, ETC) por módulo\r\n\r\nid_Users... Integer ... NOT NULL ... para ligar con la tabla de USUARIOS\r\nid_Menus ... Integer ... NOT NULL ... para ligar con la tabla de MÓDULOS de la APP\r\nForcing_Why_Delete ... nchar (1)  ... NOT NULL ... (S/N) Es el equivalente a un campo boolean por si la BD no admitiera este tipo de campos. Nos sirve para obligar al usuario a que cuando borre un registro de cualquier tabla obligue a poner el comentario de porque se borra ( o no ponerlo por si está desactivado). Por supuesto sería por cada módulo de nuestra APP pues en un módulo podemos obligarle a poner porque borra el registro y para otro módulo pues puede que no sea necesario.';

-- Volcando datos para la tabla socger.users_menus: ~0 rows (aproximadamente)
DELETE FROM `users_menus`;
/*!40000 ALTER TABLE `users_menus` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_menus` ENABLE KEYS */;


-- Volcando estructura para tabla socger.users_menus_permissions
DROP TABLE IF EXISTS `users_menus_permissions`;
CREATE TABLE IF NOT EXISTS `users_menus_permissions` (
  `Id_Users` bigint(20) NOT NULL,
  `Id_Menus` bigint(20) NOT NULL,
  `Tipo_CRUD` char(1) NOT NULL,
  `Insert_WHEN` datetime NOT NULL,
  `Insert_Id_User` bigint(20) NOT NULL,
  `Del_WHEN` datetime DEFAULT NULL,
  `Del_Id_User` bigint(20) DEFAULT NULL,
  `Del_WHY` varchar(255) DEFAULT NULL,
  `Change_WHEN` datetime DEFAULT NULL,
  `Change_Id_User` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`Id_Users`,`Id_Menus`,`Tipo_CRUD`),
  KEY `FK_users_menus_permissions_menus` (`Id_Menus`),
  CONSTRAINT `FK_users_menus_permissions_menus` FOREIGN KEY (`Id_Menus`) REFERENCES `menus` (`Id`),
  CONSTRAINT `FK_users_menus_permissions_users` FOREIGN KEY (`Id_Users`) REFERENCES `users` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Cada usuario podrá usar o no cierto módulo, pero por cada módulo tendrá por ejemplo permisos de Crear, Modificar, Imprimir. Ó solo de CONSULTA, ó sólo de Crear, etc.\r\nPara cada una de las opciones de cada mantenimiento que se vayan a usar hay que crearlas o no crearlas. Es decir, si no creamos la opción de MODIFICAR, pues el usuario no tendrá para ese módulo permisos de modificación. Si la creamos pues tendrá permiso para MODIFICAR en ese módulo\r\n\r\nEl campo a ver que tipo de opción sería Tipo_CRUD, y lo he creado nvarchar (5) por si el día de mañana creamos tipos de usos no standar al CRUD\r\nAsí que los tipos de uso por cada módulo podrían ser los siguientes:\r\n\r\nA ... Altas\r\nB ... Borrar\r\nM ... Modificar\r\nC ... Consultas\r\nI ... Imprimir\r\nT ... Todos los privilegios para el módulo elegido';

-- Volcando datos para la tabla socger.users_menus_permissions: ~0 rows (aproximadamente)
DELETE FROM `users_menus_permissions`;
/*!40000 ALTER TABLE `users_menus_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_menus_permissions` ENABLE KEYS */;


-- Volcando estructura para tabla socger.users_passwords
DROP TABLE IF EXISTS `users_passwords`;
CREATE TABLE IF NOT EXISTS `users_passwords` (
  `Id_Users` bigint(20) NOT NULL,
  `Password` varchar(250) NOT NULL,
  `Password_Expira_SN` char(1) NOT NULL DEFAULT 'S',
  `Password_Expira_Inicio` datetime DEFAULT NULL,
  `Password_Expires_Fin` datetime DEFAULT NULL,
  `Obligado_NICK_SN` char(1) NOT NULL DEFAULT 'S',
  `Insert_WHEN` datetime NOT NULL,
  `Insert_Id_User` bigint(20) NOT NULL,
  `Del_WHEN` datetime DEFAULT NULL,
  `Del_Id_User` bigint(20) DEFAULT NULL,
  `Del_WHY` varchar(255) DEFAULT NULL,
  `Change_WHEN` datetime DEFAULT NULL,
  `Change_Id_User` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`Id_Users`,`Password`),
  UNIQUE KEY `Index_Password` (`Password`),
  CONSTRAINT `FK_users_passwords_users` FOREIGN KEY (`Id_Users`) REFERENCES `users` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Un usuario puede tener diferentes contraseñas a lo largo de un periodo de tiempo. Por lo que las contraseñas se pueden generar con un periodo de caducidad. Y por supuesto puede tener diferentes contraseñas para diferentes gestiones (con una contraseña se puede entrar a una ERP de PRESENCIA, con otra a OTRO ERP, etc). Pero de momento no nos liaremos con este jaleo, pues implicaría otra tabla entre medias de la contraseña y los módulos. Pero no está mal que permitamos tener varias contraseñas ya para cada usuario.\r\n\r\nAl introducir una contraseña, podemos obligar al usuario a introducir también su NICK (descripción del usuario). Para ello utilizaremos el campo Obligado_NICK_SN\r\n\r\nLa contraseña (campo Pwd) es un campo nvarchar (300) porque puede estar generado por algún dispositivo que devuelva contraseñas cifradas, o simplemente puede ser que el usuario quiera introducir ristras largas para su PASSWORD (de memoria). Como resulta que es un campo nvarchar, sólo grabará físicamente los caracteres introducidos en el registro.\r\n\r\npwd_Expira_SN ... nchar (1)  ... NOT NULL ... (S/N) Es el equivalente a un campo boolean por si la BD no admitiera este tipo de campos. Sirve para decirle si la contraseña va a tener o no caducidad\r\npwd_Expira_Inicio ... datetime ... NULL ... Nos sirve para decirle el inicio del periodo de caducidad de la contraseña\r\npwd_Expira_Fin ... datetime ... NULL ... Nos sirve para decirle el fin del periodo de caducidad de la contraseña';

-- Volcando datos para la tabla socger.users_passwords: ~0 rows (aproximadamente)
DELETE FROM `users_passwords`;
/*!40000 ALTER TABLE `users_passwords` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_passwords` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
